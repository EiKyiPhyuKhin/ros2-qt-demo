/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pushButton;
    QPushButton *pushButton_6;
    QTabWidget *tabWidget;
    QWidget *tab;
    QPushButton *pushButton_1;
    QPushButton *pushButton_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_4;
    QPushButton *pushButton_3;
    QWidget *tab_2;
    QWidget *tab_3;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1594, 1265);
        MainWindow->setStyleSheet(QString::fromUtf8(""));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setStyleSheet(QString::fromUtf8("QWidget{\n"
"background-color:rgb(255,255,255,100);\n"
"}"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 0, 181, 71));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(200, 0, 441, 71));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(650, 0, 631, 71));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(1300, 1080, 261, 71));
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton#pushButton\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 3px solid rgb(26, 95, 180); /* Black border */\n"
"    font-family: Georgia;\n"
"    font-size: 20px;\n"
"    color: #000000; /* Black text color */\n"
"       border-radius: 30px; \n"
"      padding: 15px;\n"
"	\n"
"\n"
"}\n"
" QPushButton:hover#pushButton{\n"
"            /*background-image:#e91e63;*/\n"
"          color: grey;\n"
"}\n"
""));
        pushButton_6 = new QPushButton(centralwidget);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(1210, 10, 211, 71));
        pushButton_6->setStyleSheet(QString::fromUtf8("QPushButton#pushButton_6\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 5px solid rgb(246, 97, 81); /* Black border */\n"
"    font-family: Georgia;\n"
"    font-size: 30px;\n"
"    color: #000000; /* Black text color */\n"
"       border-radius: 25px; \n"
"      padding: 15px;\n"
"	\n"
"\n"
"}\n"
" QPushButton:hover#pushButton_6{\n"
"            /*background-image:#e91e63;*/\n"
"          color: grey;\n"
"}\n"
""));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(10, 60, 1541, 1001));
        tabWidget->setStyleSheet(QString::fromUtf8("QTabBar::tab{\n"
"    background: rgb(245, 194, 17);\n"
"    border: 2px solid #C4C4C3;\n"
"    border-bottom-color: #C2C7CB; /* same as the pane color */\n"
"    border-top-left-radius: 4px;\n"
"    border-top-right-radius: 4px;\n"
"    min-width: 8ex;\n"
"    padding: 2px;\n"
"	color: grey;\n"
"}\n"
"\n"
""));
        tabWidget->setTabShape(QTabWidget::Triangular);
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        tab->setStyleSheet(QString::fromUtf8("QWidget#tab{\n"
"border-image: url(:/icon/images/bellabot1.JPG);\n"
"}"));
        pushButton_1 = new QPushButton(tab);
        pushButton_1->setObjectName(QString::fromUtf8("pushButton_1"));
        pushButton_1->setGeometry(QRect(120, 80, 201, 201));
        pushButton_1->setStyleSheet(QString::fromUtf8("QPushButton#pushButton_1\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 16px groove rgb(255, 163, 72); /* Black border */\n"
"    font-family: ;\n"
"	font:  ;\n"
"	font: 65 14pt \"Dyuthi\";\n"
"    font-size: 80px;\n"
"    color: #000000; /* Black text color */\n"
"       border-radius: 100px; \n"
"      padding: 10px;\n"
"	\n"
"\n"
"}\n"
" QPushButton:hover#pushButton_1 {\n"
"        background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 235, 235, 206), stop:0.35 rgba(255, 188, 188, 80), stop:0.4 rgba(255, 162, 162, 80), stop:0.425 rgba(255, 132, 132, 156), stop:0.44 rgba(252, 128, 128, 80), stop:1 rgba(255, 255, 255, 0));\n"
"color: grey;\n"
"       }\n"
""));
        pushButton_2 = new QPushButton(tab);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(430, 50, 241, 241));
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton#pushButton_2\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 20px groove rgb(255, 163, 72); /* Black border */\n"
"    font-family: Dyuthi;\n"
"    font-size: 90px;\n"
"    color: #000000; /* Black text color */\n"
"       border-radius: 120px; \n"
"      padding: 12px;\n"
"	\n"
"\n"
"}\n"
" QPushButton:hover#pushButton_2 {\n"
"        background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 235, 235, 206), stop:0.35 rgba(255, 188, 188, 80), stop:0.4 rgba(255, 162, 162, 80), stop:0.425 rgba(255, 132, 132, 156), stop:0.44 rgba(252, 128, 128, 80), stop:1 rgba(255, 255, 255, 0));\n"
"color: grey;\n"
"       }\n"
"\n"
""));
        pushButton_5 = new QPushButton(tab);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(240, 300, 321, 321));
        pushButton_5->setStyleSheet(QString::fromUtf8("QPushButton#pushButton_5\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 17px groove rgb(98, 160, 234); /* color border */\n"
"	font: 75 20pt \"Gayathri\";\n"
"    font-weight:  bold;\n"
"    font-size: 80px;\n"
"    color:rgb(26, 95, 180); /* Black text color */\n"
"       border-radius: 160px;\n"
"      padding: 20px;\n"
"\n"
"}\n"
" QPushButton:hover#pushButton_5 {\n"
"        background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 255, 255, 255), stop:0.1 rgba(255, 255, 255, 255), stop:0.2 rgba(255, 176, 176, 167), stop:0.3 rgba(255, 151, 151, 92), stop:0.4 rgba(255, 125, 125, 51), stop:0.5 rgba(255, 76, 76, 205), stop:0.52 rgba(255, 76, 76, 205), stop:0.6 rgba(255, 180, 180, 84), stop:1 rgba(255, 255, 255, 0));\n"
"/*qlineargradient(x1: 0, y1: 0, x2: 1, y2: 1, stop: 0 #5588ee, stop: 1 #ee5588);*/\n"
"	color: black;\n"
"       }\n"
"\n"
""));
        pushButton_4 = new QPushButton(tab);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(20, 520, 221, 221));
        pushButton_4->setStyleSheet(QString::fromUtf8("QPushButton#pushButton_4\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 18px groove rgb(255, 163, 72); /* Black border */\n"
"    font-family: Dyuthi;\n"
"    font-size: 90px;\n"
"    color: #000000; /* Black text color */\n"
"       border-radius: 110px; \n"
"      padding: 15px;\n"
"	\n"
"\n"
"}\n"
" QPushButton:hover#pushButton_4{\n"
"        background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 235, 235, 206), stop:0.35 rgba(255, 188, 188, 80), stop:0.4 rgba(255, 162, 162, 80), stop:0.425 rgba(255, 132, 132, 156), stop:0.44 rgba(252, 128, 128, 80), stop:1 rgba(255, 255, 255, 0));\n"
"	color: grey;\n"
"       }\n"
""));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(580, 550, 181, 181));
        pushButton_3->setStyleSheet(QString::fromUtf8("QPushButton#pushButton_3\n"
"{ \n"
"\n"
"  background-color: #FFFFFF; /* White background */\n"
"    border: 15px groove rgb(255, 163, 72); /* Black border */\n"
"    font-family: Dyuthi;\n"
"    font-size: 70px;\n"
"    color: #000000; /* Black text color */\n"
"       border-radius: 90px; \n"
"      padding: 15px;\n"
"	\n"
"\n"
"}\n"
" QPushButton:hover#pushButton_3{\n"
"        background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 rgba(255, 235, 235, 206), stop:0.35 rgba(255, 188, 188, 80), stop:0.4 rgba(255, 162, 162, 80), stop:0.425 rgba(255, 132, 132, 156), stop:0.44 rgba(252, 128, 128, 80), stop:1 rgba(255, 255, 255, 0));\n"
"	color: grey;\n"
"       }\n"
""));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        tabWidget->addTab(tab_2, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        tabWidget->addTab(tab_3, QString());
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1594, 39));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuEdit = new QMenu(menubar);
        menuEdit->setObjectName(QString::fromUtf8("menuEdit"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuEdit->menuAction());
        menuEdit->addSeparator();
        menuEdit->addSeparator();

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Hello ROS2!", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "This is a demo for ROS2 Qt App", nullptr));
        label_4->setText(QString());
        pushButton->setText(QCoreApplication::translate("MainWindow", "Open New Window", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "STOP", nullptr));
        pushButton_1->setText(QCoreApplication::translate("MainWindow", "P1", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "P2", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "RTH", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "P4", nullptr));
        pushButton_3->setText(QCoreApplication::translate("MainWindow", "P3", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "Tab 1", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "Tab 2", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "Tab3", nullptr));
        menuFile->setTitle(QCoreApplication::translate("MainWindow", "File", nullptr));
        menuEdit->setTitle(QCoreApplication::translate("MainWindow", "Edit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
