/********************************************************************************
** Form generated from reading UI file 'newdialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NEWDIALOG_H
#define UI_NEWDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_newDialog
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;

    void setupUi(QDialog *newDialog)
    {
        if (newDialog->objectName().isEmpty())
            newDialog->setObjectName(QString::fromUtf8("newDialog"));
        newDialog->resize(1404, 966);
        pushButton = new QPushButton(newDialog);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(80, 140, 170, 48));
        pushButton_2 = new QPushButton(newDialog);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(350, 140, 170, 48));
        pushButton_3 = new QPushButton(newDialog);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(80, 250, 170, 48));
        pushButton_4 = new QPushButton(newDialog);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(350, 240, 170, 48));
        pushButton_5 = new QPushButton(newDialog);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(80, 350, 170, 48));
        pushButton_6 = new QPushButton(newDialog);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(350, 350, 170, 48));

        retranslateUi(newDialog);

        QMetaObject::connectSlotsByName(newDialog);
    } // setupUi

    void retranslateUi(QDialog *newDialog)
    {
        newDialog->setWindowTitle(QCoreApplication::translate("newDialog", "Dialog", nullptr));
        pushButton->setText(QCoreApplication::translate("newDialog", "PushButton", nullptr));
        pushButton_2->setText(QCoreApplication::translate("newDialog", "PushButton", nullptr));
        pushButton_3->setText(QCoreApplication::translate("newDialog", "PushButton", nullptr));
        pushButton_4->setText(QCoreApplication::translate("newDialog", "PushButton", nullptr));
        pushButton_5->setText(QCoreApplication::translate("newDialog", "PushButton", nullptr));
        pushButton_6->setText(QCoreApplication::translate("newDialog", "PushButton", nullptr));
    } // retranslateUi

};

namespace Ui {
    class newDialog: public Ui_newDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NEWDIALOG_H
